package com.aapp.texts;

import net.minecraftforge.fml.common.Mod;

@Mod(MinecraftTexts.MODID)
public class MinecraftTexts {
    public static final String MODID = "mc_texts";

    public MinecraftTexts() {
    }
}
