package com.aapp.texts;

import net.minecraft.util.Mth;

/** What is currently shown on screen. */
public final class TextState {
    public enum Mode { STATIC, FLASH, FADE, RAINBOW }

    public static volatile String[] lines = new String[0];
    public static volatile String raw = "";
    public static volatile Mode mode = Mode.STATIC;
    public static volatile int color1 = 0xFFFFFF;
    public static volatile int color2 = 0xFFFFFF;
    /** Full color cycles per second (flash / fade / rainbow). */
    public static volatile double speed = 2.0;
    /** Text scale. */
    public static volatile double size = 2.0;

    private TextState() {}

    public static void show(Mode newMode, int c1, int c2, String message) {
        mode = newMode;
        color1 = c1;
        color2 = c2;
        raw = message;
        lines = message.split("\\|");   // "|" starts a new line
    }

    public static void clear() {
        lines = new String[0];
    }

    /** RGB color to draw with right now. */
    public static int currentColor() {
        return colorFor(mode, color1, color2, speed);
    }

    public static int colorFor(Mode m, int c1, int c2, double cyclesPerSecond) {
        double t = (System.currentTimeMillis() / 1000.0) * cyclesPerSecond;
        switch (m) {
            case FLASH:
                return (((long) Math.floor(t * 2.0)) % 2 == 0) ? c1 : c2;
            case FADE: {
                float f = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * t));
                return blend(c1, c2, f);
            }
            case RAINBOW:
                return Mth.hsvToRgb((float) (t - Math.floor(t)), 1.0F, 1.0F);
            default:
                return c1;
        }
    }

    private static int blend(int a, int b, float f) {
        int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }
}
