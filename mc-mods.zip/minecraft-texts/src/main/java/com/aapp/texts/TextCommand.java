package com.aapp.texts;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Client side command, no server needed.
 *
 *   /text                                  opens the easy menu (same as pressing K)
 *   /text <message>                        plain white text
 *   /text set <message>                    same, use this if the message starts with a word like "color"
 *   /text color <color> <message>
 *   /text flash <color1> <color2> <message>   hard blink between two colors
 *   /text fade <color1> <color2> <message>    smooth fade between two colors
 *   /text rainbow <message>
 *   /text speed <cycles per second>
 *   /text size <scale>
 *   /text clear
 *
 * Colors are names (red, aqua, ...) or hex like #FF8800. Use | in a message for a new line.
 */
@Mod.EventBusSubscriber(modid = MinecraftTexts.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TextCommand {
    private static final Map<String, Integer> COLORS = new LinkedHashMap<>();
    static {
        COLORS.put("white", 0xFFFFFF);
        COLORS.put("gray", 0xAAAAAA);
        COLORS.put("dark_gray", 0x555555);
        COLORS.put("black", 0x000000);
        COLORS.put("red", 0xFF5555);
        COLORS.put("dark_red", 0xAA0000);
        COLORS.put("orange", 0xFFAA00);
        COLORS.put("yellow", 0xFFFF55);
        COLORS.put("green", 0x55FF55);
        COLORS.put("dark_green", 0x00AA00);
        COLORS.put("aqua", 0x55FFFF);
        COLORS.put("dark_aqua", 0x00AAAA);
        COLORS.put("blue", 0x5555FF);
        COLORS.put("dark_blue", 0x0000AA);
        COLORS.put("purple", 0xAA00AA);
        COLORS.put("pink", 0xFF55FF);
    }

    private static final DynamicCommandExceptionType BAD_COLOR = new DynamicCommandExceptionType(
            name -> Component.literal("Unknown color '" + name + "'. Use a name like red, or hex like #FF8800."));

    private TextCommand() {}

    private static int parseColor(String text) throws CommandSyntaxException {
        Integer named = COLORS.get(text.toLowerCase());
        if (named != null) {
            return named;
        }
        String hex = text.startsWith("#") ? text.substring(1) : text;
        if (hex.length() == 6) {
            try {
                return Integer.parseInt(hex, 16);
            } catch (NumberFormatException ignored) {
                // fall through
            }
        }
        throw BAD_COLOR.create(text);
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<CommandSourceStack, String> colorArg(String name) {
        return Commands.argument(name, StringArgumentType.word())
                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(COLORS.keySet(), builder));
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<CommandSourceStack, String> messageArg() {
        return Commands.argument("message", StringArgumentType.greedyString());
    }

    @SubscribeEvent
    public static void onRegister(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        d.register(Commands.literal("text")
                .executes(ctx -> {
                    TextScreen.open();
                    return 1;
                })
                .then(Commands.literal("clear").executes(ctx -> {
                    TextState.clear();
                    return 1;
                }))
                .then(Commands.literal("set")
                        .then(messageArg().executes(ctx -> {
                            TextState.show(TextState.Mode.STATIC, 0xFFFFFF, 0xFFFFFF,
                                    StringArgumentType.getString(ctx, "message"));
                            return 1;
                        })))
                .then(Commands.literal("color")
                        .then(colorArg("color")
                                .then(messageArg().executes(ctx -> {
                                    int c = parseColor(StringArgumentType.getString(ctx, "color"));
                                    TextState.show(TextState.Mode.STATIC, c, c,
                                            StringArgumentType.getString(ctx, "message"));
                                    return 1;
                                }))))
                .then(Commands.literal("flash")
                        .then(colorArg("color1")
                                .then(colorArg("color2")
                                        .then(messageArg().executes(ctx -> {
                                            int c1 = parseColor(StringArgumentType.getString(ctx, "color1"));
                                            int c2 = parseColor(StringArgumentType.getString(ctx, "color2"));
                                            TextState.show(TextState.Mode.FLASH, c1, c2,
                                                    StringArgumentType.getString(ctx, "message"));
                                            return 1;
                                        })))))
                .then(Commands.literal("fade")
                        .then(colorArg("color1")
                                .then(colorArg("color2")
                                        .then(messageArg().executes(ctx -> {
                                            int c1 = parseColor(StringArgumentType.getString(ctx, "color1"));
                                            int c2 = parseColor(StringArgumentType.getString(ctx, "color2"));
                                            TextState.show(TextState.Mode.FADE, c1, c2,
                                                    StringArgumentType.getString(ctx, "message"));
                                            return 1;
                                        })))))
                .then(Commands.literal("rainbow")
                        .then(messageArg().executes(ctx -> {
                            TextState.show(TextState.Mode.RAINBOW, 0xFFFFFF, 0xFFFFFF,
                                    StringArgumentType.getString(ctx, "message"));
                            return 1;
                        })))
                .then(Commands.literal("speed")
                        .then(Commands.argument("cycles_per_second", DoubleArgumentType.doubleArg(0.1, 20.0))
                                .executes(ctx -> {
                                    TextState.speed = DoubleArgumentType.getDouble(ctx, "cycles_per_second");
                                    return 1;
                                })))
                .then(Commands.literal("size")
                        .then(Commands.argument("scale", DoubleArgumentType.doubleArg(0.5, 6.0))
                                .executes(ctx -> {
                                    TextState.size = DoubleArgumentType.getDouble(ctx, "scale");
                                    return 1;
                                })))
                // plain "/text hello" - registered last so the words above win
                .then(messageArg().executes(ctx -> {
                    TextState.show(TextState.Mode.STATIC, 0xFFFFFF, 0xFFFFFF,
                            StringArgumentType.getString(ctx, "message"));
                    return 1;
                })));
    }
}
