package com.aapp.texts;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Draws the text centred above the hotbar. The position is fixed on purpose. */
@Mod.EventBusSubscriber(modid = MinecraftTexts.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TextOverlay {
    private static final int LINE_HEIGHT = 10;
    private static final int BOTTOM_MARGIN = 64; // keeps clear of the hearts / armor / xp bar

    private TextOverlay() {}

    @SubscribeEvent
    public static void onRender(RenderGuiEvent.Post event) {
        String[] lines = TextState.lines;
        if (lines.length == 0) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) {   // F1 hides the text too, handy for recording
            return;
        }

        GuiGraphics graphics = event.getGuiGraphics();
        int width = event.getWindow().getGuiScaledWidth();
        int height = event.getWindow().getGuiScaledHeight();
        float scale = (float) TextState.size;
        int color = TextState.currentColor() | 0xFF000000;

        float top = height - BOTTOM_MARGIN - lines.length * LINE_HEIGHT * scale;
        PoseStack pose = graphics.pose();
        for (int i = 0; i < lines.length; i++) {
            pose.pushPose();
            pose.translate(width / 2.0F, top + i * LINE_HEIGHT * scale, 0.0F);
            pose.scale(scale, scale, 1.0F);
            graphics.drawCenteredString(mc.font, lines[i].trim(), 0, 0, color);
            pose.popPose();
        }
    }
}
