package com.aapp.texts;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * The easy menu. Type words, tap a color, tap a style, tap SHOW TEXT.
 * Opens with the K key or by typing /text on its own.
 */
public class TextScreen extends Screen {
    private static final String[] STYLE_NAMES = {"Plain", "Flash", "Fade", "Rainbow"};
    private static final TextState.Mode[] STYLE_MODES = {
        TextState.Mode.STATIC, TextState.Mode.FLASH, TextState.Mode.FADE, TextState.Mode.RAINBOW
    };
    private static final int[] SWATCHES = {
        0xFFFFFF, 0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5555FF, 0xAA00AA, 0xFF55FF
    };
    private static final int SWATCH_W = 30;
    private static final int SWATCH_STEP = 34;
    private static final int ROW1_Y = 76;
    private static final int ROW2_Y = 108;
    private static final int STYLE_Y = 134;

    private EditBox box;
    private TextState.Mode mode = TextState.mode;
    private int color1 = TextState.color1;
    private int color2 = TextState.color2;
    private double speed = TextState.speed;
    private double size = TextState.size;

    public TextScreen() {
        super(Component.literal("Minecraft Texts"));
    }

    /** Opens the menu on the next tick (so the chat screen does not close it again). */
    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.tell(() -> mc.setScreen(new TextScreen()));
    }

    private int swatchX(int i) {
        return this.width / 2 - (SWATCHES.length * SWATCH_STEP - (SWATCH_STEP - SWATCH_W)) / 2 + i * SWATCH_STEP;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        box = new EditBox(this.font, cx - 150, 40, 300, 20, Component.literal("Your words"));
        box.setMaxLength(120);
        box.setValue(TextState.raw);
        this.addRenderableWidget(box);
        this.setInitialFocus(box);

        for (int i = 0; i < SWATCHES.length; i++) {
            final int color = SWATCHES[i];
            this.addRenderableWidget(Button.builder(Component.empty(), b -> color1 = color)
                    .bounds(swatchX(i), ROW1_Y, SWATCH_W, 18).build());
            this.addRenderableWidget(Button.builder(Component.empty(), b -> color2 = color)
                    .bounds(swatchX(i), ROW2_Y, SWATCH_W, 18).build());
        }

        for (int i = 0; i < STYLE_NAMES.length; i++) {
            final TextState.Mode m = STYLE_MODES[i];
            this.addRenderableWidget(Button.builder(Component.literal(STYLE_NAMES[i]), b -> mode = m)
                    .bounds(cx - 150 + i * 76, STYLE_Y, 72, 20).build());
        }

        this.addRenderableWidget(Button.builder(Component.literal("Slower"), b -> speed = Math.max(0.3, speed / 1.4))
                .bounds(cx - 150, 160, 70, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Faster"), b -> speed = Math.min(10.0, speed * 1.4))
                .bounds(cx - 76, 160, 70, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Smaller"), b -> size = Math.max(1.0, size - 0.5))
                .bounds(cx + 6, 160, 70, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Bigger"), b -> size = Math.min(5.0, size + 0.5))
                .bounds(cx + 80, 160, 70, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("SHOW TEXT"), b -> {
            apply();
            this.onClose();
        }).bounds(cx - 150, 188, 148, 22).build());
        this.addRenderableWidget(Button.builder(Component.literal("CLEAR TEXT"), b -> {
            TextState.clear();
            this.onClose();
        }).bounds(cx + 2, 188, 148, 22).build());
    }

    private void apply() {
        String text = box.getValue().trim();
        if (text.isEmpty()) {
            TextState.clear();
            return;
        }
        TextState.speed = speed;
        TextState.size = size;
        TextState.show(mode, color1, mode == TextState.Mode.STATIC ? color1 : color2, text);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            apply();
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;   // the game keeps running behind the menu
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        int cx = this.width / 2;

        g.drawCenteredString(this.font, "Minecraft Texts", cx, 6, 0xFFFFFF);

        // live preview
        String preview = box.getValue().isEmpty() ? "Your words show here" : box.getValue().replace('|', ' ');
        int previewColor = TextState.colorFor(mode, color1, mode == TextState.Mode.STATIC ? color1 : color2, speed) | 0xFF000000;
        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(cx, 20, 0);
        pose.scale(1.5F, 1.5F, 1.0F);
        g.drawCenteredString(this.font, preview, 0, 0, previewColor);
        pose.popPose();

        g.drawString(this.font, "Type your words (use | for a new line)", cx - 150, 30, 0xAAAAAA);
        g.drawString(this.font, "Pick a color", cx - 150, 66, 0xFFFFFF);
        boolean twoColors = mode == TextState.Mode.FLASH || mode == TextState.Mode.FADE;
        g.drawString(this.font, "Pick a second color (Flash and Fade only)", cx - 150, 98, twoColors ? 0xFFFFFF : 0x666666);

        super.render(g, mouseX, mouseY, partialTick);

        // color squares drawn on top of the blank buttons, selected one gets a bar underneath
        for (int i = 0; i < SWATCHES.length; i++) {
            int x = swatchX(i);
            g.fill(x + 4, ROW1_Y + 4, x + SWATCH_W - 4, ROW1_Y + 14, 0xFF000000 | SWATCHES[i]);
            g.fill(x + 4, ROW2_Y + 4, x + SWATCH_W - 4, ROW2_Y + 14, (twoColors ? 0xFF000000 : 0x55000000) | SWATCHES[i]);
            if (SWATCHES[i] == color1) {
                g.fill(x, ROW1_Y + 19, x + SWATCH_W, ROW1_Y + 22, 0xFFFFFF55);
            }
            if (twoColors && SWATCHES[i] == color2) {
                g.fill(x, ROW2_Y + 19, x + SWATCH_W, ROW2_Y + 22, 0xFFFFFF55);
            }
        }
        for (int i = 0; i < STYLE_MODES.length; i++) {
            if (STYLE_MODES[i] == mode) {
                int x = cx - 150 + i * 76;
                g.fill(x, STYLE_Y + 21, x + 72, STYLE_Y + 24, 0xFFFFFF55);
            }
        }
    }
}
