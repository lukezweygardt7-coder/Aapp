# Aapp - three Forge 1.20.1 mods
- aapp-chat-clear: hides command feedback from chat (client side)
- aapp-pig: /pig spawns a saddled no-AI pig that drops a book
- minecraft-texts: /text puts custom flashing/colored text above the hotbar (client side)
