package com.ddff.ddffmod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(DdffMod.MODID)
public class DdffMod {
    public static final String MODID = "ddff";

    public DdffMod() {
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new HalfHeartHandler());
        MinecraftForge.EVENT_BUS.register(new PigDropHandler());
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        HouseCommand.register(event.getDispatcher());
        PigCommand.register(event.getDispatcher());
    }
}
