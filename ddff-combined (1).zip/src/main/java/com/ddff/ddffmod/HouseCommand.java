package com.ddff.ddffmod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class HouseCommand {
    private HouseCommand() {}

    // No permission requirement, so it also works in singleplayer worlds with cheats off.
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("house").executes(ctx -> {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            HouseBuilder.build(ctx.getSource().getLevel(), player.blockPosition(), player.getDirection());
            return 1;
        }));
    }
}
