package com.aapp.chatclear;

import net.minecraftforge.fml.common.Mod;

@Mod(AappChatClear.MODID)
public class AappChatClear {
    public static final String MODID = "aapp_chat_clear";

    public AappChatClear() {
    }
}
