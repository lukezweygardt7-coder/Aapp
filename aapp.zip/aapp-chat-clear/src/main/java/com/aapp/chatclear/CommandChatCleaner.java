package com.aapp.chatclear;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client side only. Removes command feedback from chat:
 *  - "Gave ...", "Set own game mode ...", "Applied effect ..." etc. (translation keys "commands.*")
 *  - the "[Name: ...]" admin log lines (translation key "chat.type.admin")
 * Normal chat messages from players are untouched. Unknown-command / syntax errors are kept.
 */
@Mod.EventBusSubscriber(modid = AappChatClear.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommandChatCleaner {
    private CommandChatCleaner() {}

    @SubscribeEvent
    public static void onChat(ClientChatReceivedEvent event) {
        Component message = event.getMessage();
        if (message.getContents() instanceof TranslatableContents translatable) {
            String key = translatable.getKey();
            if (key.startsWith("commands.") || key.equals("chat.type.admin")) {
                event.setCanceled(true);
            }
        }
    }
}
