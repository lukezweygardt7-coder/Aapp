package com.aapp.pig;

import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class PigDropHandler {
    @SubscribeEvent
    public void onDrops(LivingDropsEvent event) {
        if (!(event.getEntity() instanceof Pig pig)) {
            return;
        }
        if (pig.level().isClientSide || !pig.getTags().contains(PigCommand.PIG_TAG)) {
            return;
        }
        event.getDrops().add(new ItemEntity(pig.level(), pig.getX(), pig.getY(), pig.getZ(), PigCommand.createBook()));
    }
}
