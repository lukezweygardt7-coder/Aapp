package com.aapp.pig;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** /pig: spawns a saddled pig with no AI that drops the special book when it dies. */
public final class PigCommand {
    public static final String PIG_TAG = "ddff_book_pig";

    private PigCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("pig").executes(ctx -> {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            ServerLevel level = ctx.getSource().getLevel();

            Pig pig = EntityType.PIG.create(level);
            if (pig == null) {
                return 0;
            }
            BlockPos front = player.blockPosition().relative(player.getDirection(), 2);
            pig.moveTo(front.getX() + 0.5, front.getY(), front.getZ() + 0.5, player.getYRot() + 180.0F, 0.0F);
            pig.setNoAi(true);
            pig.setPersistenceRequired();
            pig.addTag(PIG_TAG);
            pig.equipSaddle(SoundSource.NEUTRAL);
            level.addFreshEntity(pig);

            return 1;
        }));
    }

    /** The book the pig drops. Edit the title, author and pages here if you want to change it. */
    public static ItemStack createBook() {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Note");
        tag.putString("author", "???");

        String page1 = "DO NOT ASK WHY IT IS HERE.\n"
                + "DO NOT ENCLOSE IT.\n"
                + "LET IT OBSERVE.\n"
                + "WHEN THE TIME COMES YOU MUST FIND IT.\n"
                + "ALWAYS KEEP A SADDLE NEAR.\n"
                + "COMPLETE WITH HONESTY AND INTEGRITY.\n\n"
                + "THREE VISITS.\n"
                + "THREE SADDLES.";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            if (i > 0) {
                sb.append("\n");
            }
            sb.append("DO NOT CONTINUE TO USE THIS MOD.");
        }
        String page2 = sb.toString();

        ListTag pages = new ListTag();
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(page1))));
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(page2))));
        tag.put("pages", pages);
        return book;
    }
}
